package com.vrhorizon.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    int bg = Color.rgb(5,8,23), blue = Color.rgb(55,139,255);
    LinearLayout root, left, right;
    FrameLayout overlay;
    TextView status;
    int score=0;

    GradientDrawable shape(int c, int stroke) {
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(20,55,115), Color.rgb(8,14,39)});
        d.setCornerRadius(22); d.setStroke(2,stroke); return d;
    }
    TextView text(String s,int size,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextColor(color);
        t.setTextSize(size); t.setGravity(Gravity.CENTER); return t;
    }
    Button btn(String label, Runnable action) {
        Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackground(shape(Color.BLACK,0xff398cff));
        b.setOnClickListener(v->action.run()); return b;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildHome();
    }
    void buildHome() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.HORIZONTAL); root.setBackgroundColor(bg);
        left=eye(); right=eye();
        root.addView(left,new LinearLayout.LayoutParams(0,-1,1));
        View divider=new View(this); divider.setBackgroundColor(0xff4a91ff);
        root.addView(divider,new LinearLayout.LayoutParams(2,-1));
        root.addView(right,new LinearLayout.LayoutParams(0,-1,1));
        setContentView(root);
        makeHome(left); makeHome(right);
    }
    LinearLayout eye() {
        LinearLayout e=new LinearLayout(this); e.setOrientation(LinearLayout.VERTICAL);
        e.setGravity(Gravity.CENTER); e.setPadding(12,8,12,8); e.setBackground(shape(bg,0xff245da9));
        return e;
    }
    void makeHome(LinearLayout e) {
        TextView logo=text("◈",42,0xff72c5ff); e.addView(logo);
        TextView title=text("VR HORIZON",27,Color.WHITE); title.setTypeface(null,Typeface.BOLD); e.addView(title);
        TextView sub=text("ТВОЁ ПРОСТРАНСТВО • ТВОЯ РЕАЛЬНОСТЬ",10,0xffa8c7ff); e.addView(sub);
        GridLayout grid=new GridLayout(this); grid.setColumnCount(2);
        String[] names={"🌐 Браузер","▶ Видео","🎮 Игры","🪟 Окна","⚙ Настройки","ℹ О проекте"};
        for(String n:names) {
            Button b=btn(n,()->openSection(n));
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();
            p.width=0; p.height=dp(54); p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);
            p.setMargins(5,5,5,5); grid.addView(b,p);
        }
        e.addView(grid,new LinearLayout.LayoutParams(-1,-2));
        e.addView(text("Стерео Side-by-Side • POCO X3 Pro",10,0xff829bc9));
    }
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
    void showPanel(String heading, View content) {
        root.removeAllViews();
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20,12,20,12); page.setBackgroundColor(bg);
        TextView h=text(heading,24,Color.WHITE); h.setTypeface(null,Typeface.BOLD);
        page.addView(h,new LinearLayout.LayoutParams(-1,dp(48)));
        page.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        page.addView(btn("← На главный экран",()->buildHome()),new LinearLayout.LayoutParams(-1,dp(52)));
        root.addView(page,new LinearLayout.LayoutParams(-1,-1));
        setContentView(root);
    }
    void openSection(String n) {
        if(n.contains("Браузер") || n.contains("Видео")) {
            LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
            EditText url=new EditText(this); url.setSingleLine(true); url.setText(n.contains("Видео")?"https://m.youtube.com":"https://www.google.com");
            box.addView(url);
            WebView web=new WebView(this); web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true); web.setWebViewClient(new WebViewClient());
            box.addView(btn("Открыть адрес",()->{
                String u=url.getText().toString().trim();
                if(!u.startsWith("http")) u="https://www.google.com/search?q="+Uri.encode(u);
                web.loadUrl(u);
            }));
            box.addView(web,new LinearLayout.LayoutParams(-1,0,1));
            showPanel(n,box); web.loadUrl(url.getText().toString());
        } else if(n.contains("Игры")) {
            LinearLayout game=new LinearLayout(this); game.setGravity(Gravity.CENTER); game.setOrientation(LinearLayout.VERTICAL);
            TextView sc=text("Очки: 0",28,Color.WHITE); game.addView(sc);
            game.addView(btn("✨ ПОПАДАНИЕ",()->{score++;sc.setText("Очки: "+score);}),new LinearLayout.LayoutParams(-1,dp(90)));
            showPanel(n,game);
        } else {
            String msg;
            if(n.contains("Окна")) msg="Здесь будет система плавающих окон. В этой первой нативной сборке ещё нет пространственного трекинга и перетаскивания окон.";
            else if(n.contains("Настройки")) msg="Режим: стерео Side-by-Side. Для VR Box держи телефон горизонтально. Камера и трекинг рук будут добавлены отдельными проверенными модулями.";
            else msg="VR Horizon — нативная Android-основа. Сейчас работает меню, стерео-разделение, встроенный WebView и тестовая мини-игра. Это ранняя сборка, не готовая замена Meta Quest.";
            showPanel(n,text(msg,17,0xffdceaff));
        }
    }
}
